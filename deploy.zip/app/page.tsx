import IntelligenceDashboard from "@/components/intelligence-dashboard"

export default function Home() {
  return <IntelligenceDashboard />
}

